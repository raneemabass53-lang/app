# Flutter Grocery App 🍎

A beautiful mobile e-commerce application built with Flutter, featuring a product detail page for grocery items.

## Features

- ✨ Clean, modern UI design
- 🖼️ Product image display with Hero animations
- 🛒 Quantity selector with increment/decrement controls
- ❤️ Favorite/wishlist toggle functionality
- 📊 Product details, nutritions, and reviews sections
- 🎨 Professional styling with custom colors and typography
- 📱 Responsive layout with bottom navigation

## Screenshots

The app recreates this product detail page design:

![App Design](../brain/bc7128d0-05a2-4298-9f7f-1bec67356500/uploaded_media_1769726990970.jpg)

## Getting Started

### Prerequisites

- Flutter SDK (3.0.0 or higher)
- Dart SDK
- Android Studio or VS Code with Flutter extensions
- An Android emulator or iOS simulator

### Installation

1. Clone or navigate to this directory:
   ```bash
   cd C:\Users\ASE\.gemini\antigravity\scratch\grocery_app
   ```

2. Install dependencies:
   ```bash
   flutter pub get
   ```

3. Run the app:
   ```bash
   flutter run
   ```

## Project Structure

```
grocery_app/
├── lib/
│   └── main.dart          # Main application and ProductDetailPage
├── assets/
│   └── apple.png          # Product image asset
├── pubspec.yaml           # Flutter configuration
└── README.md             # This file
```

## Key Components

### ProductDetailPage
The main screen displaying:
- Product image
- Product name and favorite button
- Price and weight information
- Quantity selector
- Product details section
- Nutritions and reviews navigation
- Bottom navigation bar

## Customization

You can easily customize the app by modifying:
- **Colors**: Update the theme in `main.dart`
- **Product Data**: Change product name, price, image, and description
- **Images**: Replace `assets/apple.png` with your own product images

## Future Enhancements

- Add product listing page
- Implement shopping cart functionality
- Create detailed nutritions and reviews pages
- Add backend API integration
- Implement user authentication
- Add payment gateway integration

## Technologies Used

- **Flutter**: UI framework
- **Dart**: Programming language
- **Material Design**: UI components

## License

This project is created for demonstration purposes.

---

Built with ❤️ using Flutter
